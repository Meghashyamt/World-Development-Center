# IMPACT OF POPULATION ON LIFE EXPECTANCY .
#### BY NIMMANI VYSHNAVI
>## **INTRODUCTION**

With using World Development Explorer  and World bank data we try to find out about life expectancy , comparing the countries in accordance with population during a time period of 2010 to 2018. It is important to know how health issues impact the life expectancy.Why is life expectancy is less ? How to improve it? Can we improve it by reducing population and having healthy food?
Based on the world development explorer, finding out the health issue and food improvement.A Problem Analysis investigates a situation/problem in order to allow the researcher to understand more fully the problem, in order to recommend practical solutions for solving it.In addition, a Problem Analysis determines the degree of the problem and if the problem is a genuinely related to the specific site under investigated.
According to World Development Explorer we try to find out similarities and differences between four different countries **India,Bangladesh, Unites States and Germany** selected from different regions.

In our first analysis (PLOT 1)  we see life expectancy at birth versus GDP(current US $) with respect to total population.Population comparing with the country wise.
India has the highest population as well as GDP of less then 1.7T and life expectancy between 65-70 years.United states has highest GDP around 14T and life expectancy of 79 years.Germany population is less compared to other countries. And life expectancy is 81 years and GDP is between 3.3T.Bangladesh has less GDP compared to other countries around 115B and life expectancy is 70 years.

## PLOT 1
![image](https://user-images.githubusercontent.com/78320047/112743222-73aa3180-8f63-11eb-9174-4d1c3bfbd316.png)



Gross Domestic Product is increasing each year for India. And the population also with life expectancy is increasing also.Compared to other countries in 2018 ,Bangladesh has the highest GDP increase of 44.6%.India is second GDP percentage of 33.2 %.United States is 15.8% GDP.And Germany is least increase of 6.38% increase in GDP.(PLOT 2)

## PLOT 2
![image](https://user-images.githubusercontent.com/78320047/112743407-04cdd800-8f65-11eb-842b-e91613ccec58.png)



Life expectancy is high in Germany with 26.9 % followed by US with26.1 %. India following Bangladesh with 23 % and 24 % respectively.(PLOT 3)

## PLOT 3
![image](https://user-images.githubusercontent.com/78320047/112743409-0ac3b900-8f65-11eb-872f-b36c43d96195.png)



Comparing Life expectancy from 2010 to 2018 with country wise (from PLOT 4)2010- Life Expectancy of Bangladesh rise from 70 years to 72 years. In 2018, Steep increase in Life Expectancy.Germany Life expectancy in 2010 is 80 years and 2018 is 82 years. Which is Constant and as well as increase in this country.India Life expectancy in 2010 is 67 years and later on little bit increase in 2018 of 69 years.United States is like a constant format of 79 years from 2010-2018

## PLOT 4
![image](https://user-images.githubusercontent.com/78320047/112743541-32675100-8f66-11eb-9ffb-e62c7b12632d.png)



From PLOT 5 We observe that India with GDP 7% in 2010 and in 2018 it is decreased to 5%.Bangladesh in in steady increase compared from previous year till 2018. In 2010 is from 4.3% to 2018 of 6.7% increase for Bangladesh.Germany is decreasing from 2010 till 2018 . 2010 with 4.3% GDP and sudden decrease in 2011 to 2012. And in 2018 around 1% GDP.United States it is in constant range of GDP from 2010 of 1.8 % and in 2018 of 2.3% GDP.

## PLOT 5
![image](https://user-images.githubusercontent.com/78320047/112743642-09938b80-8f67-11eb-9c03-dc2afe74d02a.png)



When comparing life expectancy within high income countries and low income countries we find that high income countries i.e developed nations have higher life expectancy compared to low income countries i.e developing countries.(PLOT 6)

## PLOT 6
![image](https://user-images.githubusercontent.com/78320047/112743678-61ca8d80-8f67-11eb-9976-002daeb94c8d.png)


> **CONCLUSION**

It is observed from PLOT 7 that inflation,consumer prices (annual % ) has indirect relation with Life Expectancy of population. Inflation was high in developing countries like India, Bangladesh which had low life expectancy . Whereas in developed nations like Germany and United States Inflation was low and Life Expectancy was high.

## PLOT 7
![image](https://user-images.githubusercontent.com/78320047/112743893-4bbdcc80-8f69-11eb-90c6-f0a12b243c1d.png)



To check the table data please visit <http://www.worlddev.xyz/> and data clearly shows that high income developed countries with higher GDP has high Life expectancy compared to low income developing countries with lower GDP.


> **REFERENCES**

<http://www.worlddev.xyz/> Link directs to WORLD DEVELOPMENT EXPLORER Which is a data tool to get information regarding 200 plus countries data.

<https://datatopics.worldbank.org/world-development-indicators/> Link directs to WORLD BANK .



