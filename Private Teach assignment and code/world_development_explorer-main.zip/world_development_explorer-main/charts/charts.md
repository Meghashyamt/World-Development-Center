
All the charts and tables used in the analysis are seen here for further clarification.
